Supplemental Data
Learning Quantum Matter through Attention in Complex Space

Figure 2 and Table S1. terminal_energy_differences.csv gives the three
paired estimates for each activation. In the source columns, Q denotes the
magnetic quadratic-form energy E and L denotes the Laplacian energy.
baseline_Q is E_MagNet. energy_gain is E_MagNet minus E_Complex, in meV
per electron. frozen_energies.csv, energy_covariances.csv and
all_chain_diagnostics.csv give the fixed-state estimates and uncertainty
diagnostics. archived_18cell_display_curves.csv gives the plotted paths
from the single-run historical comparison in panel (b). These points
were recovered from the archived vector figure. training_block100.csv
gives the 100-update block means for panel (c), which uses the GELU and
MagNet-derived runs. The plotted band is one sample standard deviation
of the three run means at each block.

Figure 3. The NPZ files hold the density maps and their Fourier
amplitudes. The CSV files give the sublattice occupations and the
displayed Fourier modes. The density is scaled by the moire cell area.
The Fourier amplitudes are normalized per electron.

Figure 4 and Table S3. figure4_data.npz contains the two periodic pair
histograms, torus cells, radial bins, angular contrasts and uncertainties.
Distances on the maps are in magnetic lengths. In the radial contrast,
distances are in units of the triangular-lattice spacing for each state.
sources.json records the sampling coverage and the order of the two
states (1/3 and 3/10, respectively). same_filling_control.json compares
two fixed wavefunctions at 3/10. frozen_energy_audit.json gives endpoint
estimates and diagnostics. Errors are conditional on the trained state.

Table S2. Two_electrons contains the energy excess and the density and
mechanical-current errors for the finite configuration-interaction
benchmark. real_scaled identifies the additional Real control.

Appendix E.2. Adaptive_weights contains the 50 four- and six-electron
states and the paired energy contrasts used to compare learned and
uniform attention weights.

Figure S1. Optimizer/training_runs.json identifies the six training
trajectories and their common settings.
